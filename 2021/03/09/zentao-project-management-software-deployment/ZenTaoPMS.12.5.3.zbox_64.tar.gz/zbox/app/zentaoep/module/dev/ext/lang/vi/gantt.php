<?php
$lang->dev->tableList['relationoftasks'] = 'Mối quan hệ nhiệm vụ';
