<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPw7lv4c1CDrkw5nnQfQsSqxBAReB5E0X22YP+wHW9EyFyXIfCqiqUWhGSgz24uHgrfevtapJ
90V9uvxFiO3Q3ZRwSs9xE+eBvo6j4IWfd1QAneHoNAfyW8Td0lg7Rq5Fx/JTCcOok1pJGi3Tx4WD
jmM/nXhpcjYHGrYjEK3chReLr2k5dVBXm5Vv0bpur3XExYVyi8WQfEMwSgz7eIx56Mf2Q9JJzAqh
RmPJHVPs3VLts/siD4Q8ZzLrJhRR5N4LSml10kHx3TMNkkRXlcyUeK39Ik8uSFHw5xCCTuAbHRCf
jaceppvmzZdkysOTXHddWbPvRzFsqtiPiJuwF/UTAULUVR+Sx0vVe66V5XyTN0e+YkOckA4uZv7H
QHveD2sABsWoitsY0o0zxv7xvp82XltbeGmjVu2x7Hu2K9IU3GRyOM9hDSLnBugluxrAA/qED6UK
Rb7PAKHZ8j2GsaJ/SowhyrikZxbkiHb8xzBDDnfuANTpw3DsBERM+WpZwBCcg6WHfEJi2f5cSjz3
/g+/2fHV6lCD1IPzf2Olai1ntmh/RBHNfGfP/Fixhg1QnpglaEZ2mtYEk1WF/fTqiY+2a/3DPgDF
DOrRl5NAW8nqyDuKvVC74qL14cmZrD6s6SLwsibeURFT1crZpsq1q/7Zbix4s5aH5enXyiiKiGGi
CRxpCqKDR5S3MeIZUbfYGJa81IYqi2edYF5HkaRHD3rivT55Q1bRisZFBR8AawAaYWI6FuLL/mBn
dRl/yh2j4WYCAZ4I7coenPBzJGMiAGijrOrX5HdWMnk9zJQ6uEUA102NKxaSBVH4Elqeh6/MbRbl
AR3+JDCHcldjjNgHOeUsBLgkExnu1V4FUziLK6Z2Mihx9+2KOVQxVmSxZ/ifWF4tOMY8UXrUGnSD
iNoqIrIAIH/KmsdPxlxyTpVP8criAEGRDGGUXkMJOTzL4MNJrJwI/WmPl8j5uCj955gMsBncYMfl
CS7AdJ73fsvL2ZMvTsIomO6f2efKv8W7Gi1IGuqbk6xUhKig1NCBOOr3LMcvsOyQeFJ6mRJqfBOf
I0bnYVyMAryG9Vcoh1GH6hpmHnF8vOnIcnt/NDzS12Y4axjMOJJiWSXbWCocQVJBXiHk/wB9CZ4W
VHt2OZMMBscNe/0S39FJFrPalWtOfz4U5Y47k4sPiYRvrINAQMi0Dv9FWnUhc1pVfpHTrGQ+XNPZ
Zc0QblFn7O1+OR7eRW7XTDdyCjPMPNwhDFkW+o3qpvFp2ylnTBYiHa8EY+jqDkBF7Q+0mhF1iokO
Oc+8ShWhzK0LoBWtv7u0KIShnVAvZuPXDYpDNXpl4qmNdz1dPGocTOxyI54zQgQ8EnVF7w727n2E
TRHo5EQZWJ9wacduOV8XmndcQAyFHqeQXS06f8YcSH9u8kGVqo1H0HnD6m7eEroeVgOFoor0p8iF
SXdtGHXY+iKgrtbpP5lmsv7lEuNndqvJLNS+/kONcPp8xL6fN/Hg6wshRQvvjGWnfcFPFn234N8R
Bzgjl09+fcBY0Y4Foc6VjDJTrSYfgf3C6XXJ1ZI9wTI1L7sAD/s8ZTV8IJQCoPW5rpIEU02hlhYn
Yftf5e2jWyQrTHMMHSqBK2YlGeHK68tRxxD+XIVqxaqLrr4DOGb6t5CW8hEXaY5D2Yanufe4n+TN
7EwMgUpl1bWX3SQXBnwiAox1VqaW1cBgYr05xPjWATY1QjMqK06bfjHp7J6p64pS+MlenNnQ2fy0
7MgzksL2H4GYPnaTfWygQqbftDJ4ItPo5/SCdwVo0KdHr19kjI9xy5xhueQJ8bVD8XCPQBJz4F/4
Q4iARx86jevm1BvY7TafmPj+oArtAUVr2A2evaqtFReuEx5jp6YfOQM7LavfWWLRyt49l138/B8j
tcnpllXlLY7+7UOnMDYUGxfA960tUQQ5RthCjTgU2ZRJ/m4C0jXO5emEIovf5+LiN9zvndx2LLgZ
ZJf/ULILwAQzhV1+sJAlHYPb2h235fiWqOGLoHX2VahkqKR8rv39Z6HmMAQEmz9d0QYbYkl33rR8
V86whCvg/T2cGvAQgwnHGPEV0TKh/5dPwuWINuYCbI7Zidx0YZvGAyIYldjSumQhQOIDqKsoL1zn
TYKsYdiSmQzOBGuHYIITk0ydTwF/JlXngJqD//1/Q1MGnKKNpYPt49MuWpCkyMiulxCxGISbbjQb
i4XZ2h6WWbCfxefsrAbcrU7gFTxOUYqGXpuKFiUDuR5C6ZK45W8LzxTOsScIlD0fFyPBHRdtiyOm
fJkDqtsxUmcijvtgNJZB7izTIfzjzU/1WHELgu3Y/iU+8wgzh5hlp63Vm527fQoFPXHH2UgjXE6B
pXTfIT8rMrV7HwzhlGsxyDJVWeWPcLSa5yK/guFC2SLD4ZgFbXknTPZy+FawwW3VvKLZxi9/Kw/F
ePxAix7cTdU55VlQadKT4KsUBMl/8JIjFPloq34VQ1upDGv0wH0XexU1UtLl6AT3XIGY1vFOkmn5
CbJHVhsgpO0h7HfDSn4Ex9p8ch2KgtZZS0+dgvdMjQLabUeQ8/AP7nSOHDYk+lFEPoEK5xC7kW4Z
6IxKlIB6hVn0RCNhZBap2tutsN1W7mt48fzBa+1hhNNBsm6MzCzcwRc8bt92v+EeE28wg0yFospS
vHkToh8z35HJ+yUemTKtr/xuaW2fisRHO+6jzP3LdMpFd+VkkE1eJHsZEyTVc1MGu7VYJJQ0GZFD
eZWbPxvS8G064HC3XdxhvTOdoeLbTFP5sq2kWxNdduqRXk9q7wpvCdA4s3WaBegQvjq5kT6rq5L7
CUL17Z8ne9CVkGxShPLm9PpdvFheIbhL73Eg2YviEkRqTv185s0GkCgi6XQFsABRnz3P9b5866zB
8UeNfUfozWprPCdMKvdGRKfgmoG+4Qn85lNOqko5OjAv0wSsgbGMpSA4piNgo3xzsZB122/dign5
kBrd4IiYrjcN5obGtqjP3eXXbW13P6AcLMe9EXYbx64nWRZFgLucls19cXb8GgVsYOZuWfvuLvOv
dUCvQmpefB+r/CYZHm==