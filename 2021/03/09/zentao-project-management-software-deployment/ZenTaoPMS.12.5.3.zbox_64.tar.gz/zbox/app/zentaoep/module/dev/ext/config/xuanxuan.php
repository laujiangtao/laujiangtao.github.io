<?php
$config->dev->group['im']                  = 'xuanxuan';
$config->dev->group['im_chatuser']         = 'xuanxuan';
$config->dev->group['im_message']          = 'xuanxuan';
$config->dev->group['im_messagestatus']    = 'xuanxuan';
$config->dev->group['im_chat']             = 'xuanxuan';
$config->dev->group['im_client']           = 'xuanxuan';
$config->dev->group['im_conference']       = 'xuanxuan';
$config->dev->group['im_conferenceaction'] = 'xuanxuan';
$config->dev->group['im_queue']            = 'xuanxuan';

$config->dev->tableMap['im_chatuser']         = 'im';
$config->dev->tableMap['im_message']          = 'message';
$config->dev->tableMap['im_messagestatus']    = 'message';
$config->dev->tableMap['im_chat']             = 'im';
$config->dev->tableMap['im_client']           = 'client';
$config->dev->tableMap['im_conference']       = 'owt';
$config->dev->tableMap['im_conferenceaction'] = 'owt';
$config->dev->tableMap['im_queue']            = 'message';
