<?php
$lang->dev->tableList['ops']     = 'OPS';
$lang->dev->tableList['host']    = 'Host';
$lang->dev->tableList['asset']   = 'Asset';
$lang->dev->tableList['serverroom'] = 'Server Room';
$lang->dev->tableList['service']    = 'Dịch vụ';
$lang->dev->tableList['deploy']  = 'Triển khai';
$lang->dev->tableList['deploystep'] = 'Triển khai bước';
$lang->dev->tableList['deployproduct'] = 'Triển khai Product';
$lang->dev->tableList['deployscope']   = 'Phạm vi triển khai';

$lang->dev->groupList['ops'] = 'OPS';
