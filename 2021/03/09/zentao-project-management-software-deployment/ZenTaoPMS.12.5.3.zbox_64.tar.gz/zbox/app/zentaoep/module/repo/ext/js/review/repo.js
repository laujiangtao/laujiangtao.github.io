$(document).ready(function()
{
    $('#' + browseType + 'Tab').addClass('btn-active-text');
});
