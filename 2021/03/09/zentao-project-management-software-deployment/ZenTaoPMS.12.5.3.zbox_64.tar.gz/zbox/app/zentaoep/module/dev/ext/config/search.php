<?php
$config->dev->group['searchindex']  = 'search';
$config->dev->group['searchdict']  = 'search';

$config->dev->tableMap['searchindex'] = 'search';
