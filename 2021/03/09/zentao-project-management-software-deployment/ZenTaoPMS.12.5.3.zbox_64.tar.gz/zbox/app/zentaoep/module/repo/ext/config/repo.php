<?php
$config->repo->editor = new stdclass();
$config->repo->editor->view = array('id' => 'commentText', 'tools' => 'simpleTools');
$config->repo->editor->diff = array('id' => 'commentText', 'tools' => 'simpleTools');
