<?php
$lang->dev->groupList['xuanxuan']= '客戶端';

$lang->dev->tableList['im_chatuser']         = '客戶端用戶';
$lang->dev->tableList['im_message']          = '客戶端消息';
$lang->dev->tableList['im_messagestatus']    = '客戶端狀態';
$lang->dev->tableList['im_chat']             = '客戶端會話';
$lang->dev->tableList['im_client']           = '客戶端版本更新';
$lang->dev->tableList['im_conference']       = '音視頻會議';
$lang->dev->tableList['im_conferenceaction'] = '會議action';
$lang->dev->tableList['im_queue']            = '客戶端推送';
