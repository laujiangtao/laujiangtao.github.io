<?php
$lang->dev->tableList['searchdict']  = '搜索字典';
$lang->dev->tableList['searchindex'] = '搜索索引';

$lang->dev->groupList['search'] = '搜索';
