<?php
$config->dev->group['feedback'] = 'feedback';
$config->dev->group['faq']      = 'feedback';
$config->dev->group['feedbackview']    = 'feedback';
$config->dev->group['feedbackproduct'] = 'feedback';
