<?php
$lang->dev->tableList['faq']             = 'Faq';
$lang->dev->tableList['feedbackview']    = '反馈视图';
$lang->dev->tableList['feedback']        = '反馈';
$lang->dev->tableList['feedbackproduct'] = '反馈权限';

$lang->dev->groupList['feedback'] = '反馈';
