<?php
$lang->report->reportExport = 'Xuất báo cáo';
