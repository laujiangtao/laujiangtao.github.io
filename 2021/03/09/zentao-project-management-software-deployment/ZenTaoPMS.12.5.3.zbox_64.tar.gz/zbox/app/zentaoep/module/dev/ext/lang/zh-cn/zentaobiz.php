<?php
$lang->dev->tableList['ops']           = '运维';
$lang->dev->tableList['host']          = '主机';
$lang->dev->tableList['asset']         = '资产';
$lang->dev->tableList['serverroom']    = '机房';
$lang->dev->tableList['service']       = '服务';
$lang->dev->tableList['deploy']        = '上线';
$lang->dev->tableList['deploystep']    = '上线步骤';
$lang->dev->tableList['deployproduct'] = '上线产品';
$lang->dev->tableList['deployscope']   = '上线范围';

$lang->dev->groupList['ops'] = '运维';
