<?php
$lang->report->errorExportChart = '该浏览器不支持Canvas图像导出功能，请换其他浏览器。';
$lang->report->errorNoChart     = '还没有报表数据！';
$lang->report->exportName       = '%s报表';
$lang->report->exportNotice     = '由禅道专业版导出';
$lang->report->export           = '导出报表';
