$(function(){$('.proversion').parent().remove();});
