<?php
$config->dev->group['effort'] = 'my';
