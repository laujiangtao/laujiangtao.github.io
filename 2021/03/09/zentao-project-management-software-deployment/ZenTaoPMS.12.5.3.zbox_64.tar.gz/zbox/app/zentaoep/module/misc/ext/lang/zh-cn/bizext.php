<?php
unset($lang->misc->zentao->about['proversion']);

$lang->misc->annualDesc = '8.7版本后，新增年度总结功能，可以到『统计->年度总结』页面查看。 是否现在<a href="%s" target="_blank" id="showAnnual" class="btn btn-mini btn-primary">查看</a>';
