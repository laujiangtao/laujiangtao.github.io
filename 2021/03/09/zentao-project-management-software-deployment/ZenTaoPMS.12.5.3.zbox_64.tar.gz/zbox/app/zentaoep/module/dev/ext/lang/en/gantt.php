<?php
$lang->dev->tableList['relationoftasks'] = 'Task Relation';
