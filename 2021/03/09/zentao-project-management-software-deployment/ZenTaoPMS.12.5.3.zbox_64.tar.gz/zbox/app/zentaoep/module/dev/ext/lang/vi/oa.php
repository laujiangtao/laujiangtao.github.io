<?php
$lang->dev->tableList['makeup']  = 'Makeup';
$lang->dev->tableList['attend']  = 'Chấm công';
$lang->dev->tableList['holiday']    = 'Ngày lễ';
$lang->dev->tableList['leave']   = 'Nghỉ phép';
$lang->dev->tableList['lieu']    = 'Lieu';
$lang->dev->tableList['overtime']   = 'Ngoài giờ';
$lang->dev->tableList['attendstat'] = 'Có mặt';
$lang->dev->tableList['trip']    = 'Trip';

$lang->dev->groupList['oa'] = 'OA';
