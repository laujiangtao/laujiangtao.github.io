<?php
$lang->dev->tableList['ops']           = 'OPS';
$lang->dev->tableList['host']          = 'Host';
$lang->dev->tableList['asset']         = 'Asset';
$lang->dev->tableList['serverroom']    = 'Server Room';
$lang->dev->tableList['service']       = 'Service';
$lang->dev->tableList['deploy']        = 'Deploy';
$lang->dev->tableList['deploystep']    = 'Deploy Step';
$lang->dev->tableList['deployproduct'] = 'Deploy Product';
$lang->dev->tableList['deployscope']   = 'Deploy Scope';

$lang->dev->groupList['ops'] = 'OPS';
