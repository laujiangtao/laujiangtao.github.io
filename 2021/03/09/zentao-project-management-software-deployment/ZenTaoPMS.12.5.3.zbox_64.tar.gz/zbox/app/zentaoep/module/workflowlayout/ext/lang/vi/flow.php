<?php
$lang->workflowlayout->positionList['view']['basic'] = 'Thông tin cơ bản';
$lang->workflowlayout->positionList['view']['info']  = 'Chi tiết';

$lang->workflowlayout->positionList['edit']['basic'] = 'align-right';
$lang->workflowlayout->positionList['edit']['info']  = 'align-left';
