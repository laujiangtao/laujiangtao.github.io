<?php
$lang->workflowlayout->positionList['view']['basic'] = 'Basic Info';
$lang->workflowlayout->positionList['view']['info']  = 'Detail';

$lang->workflowlayout->positionList['edit']['basic'] = 'align-right';
$lang->workflowlayout->positionList['edit']['info']  = 'align-left';

$lang->workflowlayout->error->emptyCustomFields = "Go to [Workflow] => [%s] => [Field] to add fields.";
