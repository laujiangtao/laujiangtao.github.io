<?php
$lang->dev->tableList['faq']             = 'Faq';
$lang->dev->tableList['feedbackview']    = 'Feedback View';
$lang->dev->tableList['feedback']        = 'Feedback';
$lang->dev->tableList['feedbackproduct'] = 'Right';

$lang->dev->groupList['feedback'] = 'Feedback';
