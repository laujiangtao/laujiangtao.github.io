<?php
unset($lang->misc->zentao->about['proversion']);

$lang->misc->annualDesc  = 'Sau phiên bản 8.7, chức năng báo cáo năm mới có thể được xem trên trang 『Báo cáo->Tóm tắt năm』. <a href="%s" target="_blank" id="showAnnual" class="btn btn-mini btn-primary">Xem ngay</a>.';
