<?php
$lang->dev->groupList['xuanxuan']= 'Client';

$lang->dev->tableList['im_chatuser']         = 'Client Users';
$lang->dev->tableList['im_message']          = 'Client Message';
$lang->dev->tableList['im_messagestatus']    = 'Client Message Status';
$lang->dev->tableList['im_chat']             = 'Client Chat';
$lang->dev->tableList['im_client']           = 'Client Upgrade';
$lang->dev->tableList['im_conference']       = 'Client Conference';
$lang->dev->tableList['im_conferenceaction'] = 'Client Conference Action';
$lang->dev->tableList['im_queue']            = 'Client Queue';
