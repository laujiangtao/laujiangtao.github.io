<?php
$lang->dev->tableList['faq']             = 'Faq';
$lang->dev->tableList['feedbackview']    = '反饋視圖';
$lang->dev->tableList['feedback']        = '反饋';
$lang->dev->tableList['feedbackproduct'] = '反饋權限';

$lang->dev->groupList['feedback'] = '反饋';
