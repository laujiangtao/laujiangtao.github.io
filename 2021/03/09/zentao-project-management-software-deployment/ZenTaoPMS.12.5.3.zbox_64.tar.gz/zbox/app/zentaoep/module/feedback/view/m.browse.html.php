<?php include '../../common/view/m.header.html.php';?>
<?php $viewMethod = 'view'?>
<?php include './m.data.html.php';?>
<?php include '../../common/view/m.footer.html.php';?>
