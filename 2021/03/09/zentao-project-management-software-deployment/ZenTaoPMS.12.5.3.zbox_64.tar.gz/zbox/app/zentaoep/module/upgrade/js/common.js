$(function()
{
    setTimeout('setPing()', 1000 * 60 * 10);
});
