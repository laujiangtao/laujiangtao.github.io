<?php
$config->dev->group['sms'] = 'message';
