<?php
$this->loadExtension('zentaobiz')->appendExec($zentaoVersion);
