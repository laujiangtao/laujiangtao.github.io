<?php
$lang->report->errorExportChart = 'Your browser does not support Canvas exporting. Try other browsers.';
$lang->report->errorNoChart     = 'No data!';
$lang->report->exportName       = '%s Report';
$lang->report->exportNotice     = 'Export by ZenTao Pro!';
$lang->report->export           = 'Export Statistics';
