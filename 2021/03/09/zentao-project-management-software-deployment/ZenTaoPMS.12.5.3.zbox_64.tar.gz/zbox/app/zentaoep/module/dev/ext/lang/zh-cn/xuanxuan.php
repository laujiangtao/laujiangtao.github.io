<?php
$lang->dev->groupList['xuanxuan']= '客户端';

$lang->dev->tableList['im_chatuser']         = '客户端用户';
$lang->dev->tableList['im_message']          = '客户端消息';
$lang->dev->tableList['im_messagestatus']    = '客户端状态';
$lang->dev->tableList['im_chat']             = '客户端会话';
$lang->dev->tableList['im_client']           = '客户端版本更新';
$lang->dev->tableList['im_conference']       = '音视频会议';
$lang->dev->tableList['im_conferenceaction'] = '会议action';
$lang->dev->tableList['im_queue']            = '客户端推送';
