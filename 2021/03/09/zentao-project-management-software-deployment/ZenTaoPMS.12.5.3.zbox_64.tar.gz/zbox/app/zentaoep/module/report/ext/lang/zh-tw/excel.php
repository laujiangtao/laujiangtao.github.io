<?php
$lang->report->reportExport = '統計導出';
