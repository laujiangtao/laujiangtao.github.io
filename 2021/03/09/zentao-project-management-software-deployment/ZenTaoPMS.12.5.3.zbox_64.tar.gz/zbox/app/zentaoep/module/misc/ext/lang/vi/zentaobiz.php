<?php
$lang->misc->annualDesc  = 'ZenTao 3.6+ đã thêm Tóm tắt hàng năm vào trang 『Báo cáo->Tóm tắt năm』. <a href="%s" target="_blank" id="showAnnual" class="btn btn-mini btn-primary">Kiểm tra nó</a>.';
