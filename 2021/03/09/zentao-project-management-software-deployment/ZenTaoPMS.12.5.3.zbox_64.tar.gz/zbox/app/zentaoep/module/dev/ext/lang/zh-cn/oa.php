<?php
$lang->dev->tableList['makeup']        = '补班';
$lang->dev->tableList['attend']        = '考勤';
$lang->dev->tableList['holiday']       = '节假日';
$lang->dev->tableList['leave']         = '请假';
$lang->dev->tableList['lieu']          = '调休';
$lang->dev->tableList['overtime']      = '加班';
$lang->dev->tableList['attendstat']    = '考勤统计';
$lang->dev->tableList['trip']          = '出差';

$lang->dev->groupList['oa'] = '办公';
