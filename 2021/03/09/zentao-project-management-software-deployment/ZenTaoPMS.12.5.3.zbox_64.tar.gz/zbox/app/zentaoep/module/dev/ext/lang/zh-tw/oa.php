<?php
$lang->dev->tableList['makeup']        = '補班';
$lang->dev->tableList['attend']        = '考勤';
$lang->dev->tableList['holiday']       = '節假日';
$lang->dev->tableList['leave']         = '請假';
$lang->dev->tableList['lieu']          = '調休';
$lang->dev->tableList['overtime']      = '加班';
$lang->dev->tableList['attendstat']    = '考勤統計';
$lang->dev->tableList['trip']          = '出差';

$lang->dev->groupList['oa'] = '辦公';
