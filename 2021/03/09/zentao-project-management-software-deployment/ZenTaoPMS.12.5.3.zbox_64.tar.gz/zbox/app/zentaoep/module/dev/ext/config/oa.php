<?php
$config->dev->group['attend']        = 'oa';
$config->dev->group['holiday']       = 'oa';
$config->dev->group['leave']         = 'oa';
$config->dev->group['lieu']          = 'oa';
$config->dev->group['overtime']      = 'oa';
$config->dev->group['attendstat']    = 'oa';
$config->dev->group['trip']          = 'oa';
$config->dev->group['makeup']        = 'oa';

$config->dev->tableMap['attendstat'] = 'attend';
