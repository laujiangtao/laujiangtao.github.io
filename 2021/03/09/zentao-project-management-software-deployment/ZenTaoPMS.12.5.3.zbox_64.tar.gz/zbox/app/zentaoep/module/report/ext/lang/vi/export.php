<?php
$lang->report->errorExportChart = 'Trình duyệt của bạn không hỗ trợ xuất Canvas. Hãy thử các trình duyệt khác.';
$lang->report->errorNoChart  = 'Không có dữ liệu!';
$lang->report->exportName    = '%s báo cáo';
$lang->report->exportNotice  = 'Xuất bởi ZenTao Pro!';
$lang->report->export     = 'Xuất thống kê';
