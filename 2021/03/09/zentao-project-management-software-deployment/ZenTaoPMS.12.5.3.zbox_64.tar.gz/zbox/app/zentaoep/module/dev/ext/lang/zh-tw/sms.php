<?php
$lang->dev->tableList['sms'] = '短信配置';
