<?php
$lang->dev->tableList['faq']    = 'Faq';
$lang->dev->tableList['feedbackview'] = 'Xem phản hồi';
$lang->dev->tableList['feedback']  = 'Phản hồi';
$lang->dev->tableList['feedbackproduct'] = 'Right';

$lang->dev->groupList['feedback'] = 'Phản hồi';
