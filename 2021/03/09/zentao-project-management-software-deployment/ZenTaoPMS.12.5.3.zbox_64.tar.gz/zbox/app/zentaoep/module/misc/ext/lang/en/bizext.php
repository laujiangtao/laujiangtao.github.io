<?php
unset($lang->misc->zentao->about['proversion']);

$lang->misc->annualDesc  = 'After version 8.7, the new annual report function can be viewed on the 『Report->Annual Summary』 page. <a href="%s" target="_blank" id="showAnnual" class="btn btn-mini btn-primary">See now</a>.';
