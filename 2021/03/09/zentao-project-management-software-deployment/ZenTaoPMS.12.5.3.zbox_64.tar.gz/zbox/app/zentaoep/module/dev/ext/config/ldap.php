<?php
$config->dev->group['ldap'] = 'admin';
