<?php
$lang->dev->tableList['ops']           = '運維';
$lang->dev->tableList['host']          = '主機';
$lang->dev->tableList['asset']         = '資產';
$lang->dev->tableList['serverroom']    = '機房';
$lang->dev->tableList['service']       = '服務';
$lang->dev->tableList['deploy']        = '上線';
$lang->dev->tableList['deploystep']    = '上線步驟';
$lang->dev->tableList['deployproduct'] = '上線產品';
$lang->dev->tableList['deployscope']   = '上線範圍';

$lang->dev->groupList['ops'] = '運維';
