<?php
$config->dev->group['relationoftasks'] = 'project';

$config->dev->tableMap['relationoftasks'] = 'project-gantt';
