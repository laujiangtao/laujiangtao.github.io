<?php
echo 'start from hellp.test2.php<br>';
