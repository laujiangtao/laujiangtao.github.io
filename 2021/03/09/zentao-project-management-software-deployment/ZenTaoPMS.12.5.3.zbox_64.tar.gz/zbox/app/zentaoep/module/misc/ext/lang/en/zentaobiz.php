<?php
$lang->misc->annualDesc  = 'ZenTao 3.6+ has added Annual Summary to 『Report->Annual Summary』 page. <a href="%s" target="_blank" id="showAnnual" class="btn btn-mini btn-primary">Check it now</a>.';
