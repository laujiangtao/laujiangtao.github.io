<?php
$lang->dev->tableList['makeup']        = 'Makeup';
$lang->dev->tableList['attend']        = 'Attend';
$lang->dev->tableList['holiday']       = 'Holiday';
$lang->dev->tableList['leave']         = 'Leave';
$lang->dev->tableList['lieu']          = 'Lieu';
$lang->dev->tableList['overtime']      = 'Overtime';
$lang->dev->tableList['attendstat']    = 'Attendance';
$lang->dev->tableList['trip']          = 'Trip';

$lang->dev->groupList['oa'] = 'OA';
