<?php
$lang->report->errorExportChart = '該瀏覽器不支持Canvas圖像導出功能，請換其他瀏覽器。';
$lang->report->errorNoChart     = '還沒有報表數據！';
$lang->report->exportName       = '%s報表';
$lang->report->exportNotice     = '由禪道專業版導出';
$lang->report->export           = '導出報表';
